# Architecture

## Persistent Digivolution architecture (v0.13.0)

`UDMFPlayerDigimonComponent` is the sole durable Digivolution authority for owned Digimon. A path is authored as `FDMFDigivolutionRequirement` on the current `UDMFDigimonSpeciesData`; it references a target species plus progression/Care/economy requirements and mutation/presentation policies. The client may evaluate this data for UI, but the server always resolves the current owned instance and revalidates the path before mutation.

Digivolution preserves the owned individual rather than deleting/recreating its account record. `FDMFDigimonInstance::SpeciesId` changes while the instance GUID, nickname, Level/EXP, ABI/CAM, Care state and other individual progression remain associated with the same persistent record. Save schema v5 adds `OriginSpeciesId` and `DigivolutionHistory`; legacy records are normalized on authoritative hydration.

For a stored/unsummoned Party or Bank individual, the server applies the mutation directly to the correct owner-only Fast Array item, marks that item/array dirty, persists immediately and returns the owner result. For the currently summoned active partner, the mutation is intentionally deferred behind a short server-owned world presentation. The existing actor reliably multicasts VFX/audio, the owner controller may hide modal HUD, and conflicting partner/storage/Care/combat commands remain locked. At completion the server revalidates the same path, commits persistence, then `SpawnOrRefreshActivePartner` destroys the old public actor and spawns the destination species `WorldActorClass` with the same active instance GUID. Normal actor replication—not private Party/Bank replication—publishes the transformed world form to observers.

Species resolution remains Primary Asset Manager-first. v0.13 also walks Digivolution links reachable from configured starter species as a convenience fallback, but production/package configuration should continue scanning all `DMFDigimonSpeciesData` recursively as Primary Assets so evolved/materialized forms are directly resolvable and cooked.

The native `UDMFDigimonInventoryWidget` extends the existing shared shell with `DIGIVOLUTION`. It reads Party+Bank owner state, displays path evaluations and invokes the same server API; no UMG object owns species, stat, cost or persistence authority.

## Party + Bank / Boxes architecture (v0.12.0)

`UDMFPlayerDigimonComponent` now owns two explicit account-storage tiers while retaining historical field/API names for compatibility:

- **Party** — `ReplicatedInventory` / serialized `DigimonInventory`, now the active field roster and capped to `MaxPartyDigimon` (six by default).
- **Bank / Boxes** — `ReplicatedBank` / serialized `DigimonBank`, persistent account storage with configurable capacity and native paging.

Both replicated containers use Fast Array replication with `COND_OwnerOnly`; another player never receives a peer's complete Party or Bank contents. The public replicated world representation remains the currently spawned Digimon actor and its combat/nameplate state.

All durable storage mutations enter through the owning PlayerState component's reliable Server RPCs. Authority validates source membership, instance GUIDs, Party/Bank capacities, destination indices, Care sequence state and the default combat-switch lock before committing a transfer. Full-Party Bank withdrawals use one atomic server transaction: the selected Bank instance replaces the chosen Party slot and the outgoing Party instance is returned to Bank. The final Party member cannot be deposited.

The active partner GUID is reconciled inside the same authoritative mutation. Swapping the active slot promotes the incoming instance and refreshes the spawned partner safely; normal world replication then presents that actor change to observers. Materialization uses the same storage contract: Party first, Bank overflow, reject only when both tiers have no legal capacity.

Save schema v4 migrates legacy pre-v0.12 `DigimonInventory` collections without intentional ownership loss: the previous active partner is promoted first, remaining legacy entries fill Party in order, overflow is merged into `DigimonBank`, and instance GUIDs are de-duplicated. Existing oversized legacy Bank data is preserved rather than truncated.

`UDMFPartyQuickBarWidget` is local owner presentation over the same Party Fast Array. Normal mode is hit-test transparent; Tab interaction mode changes only the local PlayerController input/cursor state. Clicking a Party member still calls the authoritative partner-selection RPC. The quick bar therefore adds no parallel inventory authority or replicated HUD state.

## Player camera boom architecture (v0.11.1)

`ADMFPlayerAvatarCharacter` owns the framework camera boom and the local requested zoom distance. The default mouse-wheel bindings only update that local requested distance; `Tick` interpolates `USpringArmComponent::TargetArmLength` toward it after clamping against the Project Settings minimum/maximum. No camera distance, zoom input or interpolation state enters replication or persistence.

The spring arm keeps `bDoCollisionTest=true` and `ProbeChannel=ECC_Camera`, preserving normal wall/world obstruction behavior. Separately, `RefreshCameraCollisionPolicy` applies the global character-safe rule to every primitive component owned by framework player avatars and Digimon: `ECC_Camera = Ignore`. This deliberately changes only the camera channel, leaving Pawn/Visibility/combat/interaction collision semantics untouched. Blueprint-added primitive components are included so cosmetic/collision additions cannot accidentally reintroduce third-person camera popping.

Projects using Enhanced Input can disable the framework mouse-wheel binding while retaining the same local zoom implementation through the Blueprint callable zoom API.

## Global music presentation director (v0.11.0)

`UDMFMusicSubsystem` is a GameInstance-lifetime, local presentation subsystem that resolves one semantic state: `Frontend`, `OpenWorld`, `Battle` or `None`. It survives normal frontend/gameplay travel and owns persistent 2D AudioComponents so state changes can crossfade rather than hard-cut.

Map context comes from the configured `FrontendMap` / `OpenWorldMap` with framework GameMode/PlayerController fallbacks. Battle context comes only from the local active partner's existing replicated `UDMFDigimonCombatComponent::CombatState`; `Chasing`, `Attacking` and `Recovering` are active battle states. A selected target alone is not. A short local release delay de-bounces the return to exploration music.

The subsystem never authors combat state and adds no replicated music variable/RPC. Every client derives its own soundtrack from already replicated gameplay truth, allowing nearby players to be in different soundtrack states while preserving one server-authoritative combat simulation. Dedicated servers do not render AudioComponents.

## Authority model

`ADMFMMOGameMode` is the server authority for authenticated entry. `ADMFPlayerState` owns both replicated player-facing state components: `UDMFPlayerAvatarComponent` for the human avatar skin and `UDMFPlayerDigimonComponent` for Digimon collection/partner state. Keeping both on PlayerState preserves ownership across pawn replacement and gives client requests a connection-owned RPC route.

`ADMFPlayerAvatarCharacter` is the ready-to-use replicated third-person gameplay pawn. Character skins are visual Primary Data Assets (`UDMFPlayerSkinData`), not alternate pawn classes. A skin change therefore cannot replace possession, collision authority, inventory ownership or movement code.

## Player footstep presentation architecture

`ADMFPlayerAvatarCharacter` owns the v0.10.4 player-only footstep presentation. It accumulates **grounded horizontal distance travelled** from `CharacterMovement` rather than depending on AnimBP notifies, so all framework player skins and custom/Enhanced Input movement stacks inherit the feature automatically. Walk, sprint and crouch stride distances are project settings; the audio source is placed at the capsule base to avoid skeleton-specific socket assumptions.

A remote owning client predicts only its own local audio for responsiveness. The server performs the same movement-derived cadence independently and sends an Unreliable NetMulticast cosmetic event to observers. The owning remote client ignores that returned multicast, so it never hears a doubled step. This event is presentation-only: movement replication remains Unreal CharacterMovement authority and no durable footstep property or account state is introduced. Digimon classes do not execute this path.

`UDMFPlayerDigimonComponent` owns Party, Bank and active-partner state. Both private storage tiers use `FFastArraySerializer` with `COND_OwnerOnly`; see the v0.12 Party/Bank contract above.

The server performs starter validation, constructs the unique Digimon instance, persists it, and spawns the authoritative 3D partner actor. The client never supplies trusted stats or an arbitrary actor class. Partner species resolution prefers UE Asset Manager registration and falls back to the configured starter roster for onboarding.

## World chat architecture

`UDMFWorldChatWidget` is a local presentation surface owned by the local `ADMFMMOPlayerController`. Pressing Enter changes only local input focus; it does not create a client-authoritative chat stream. The client submits raw text to its owned controller Server RPC.

The server controller sanitizes and rate-limits the request, then `ADMFMMOGameMode` resolves the sender's public PlayerState name, stamps server UTC metadata, appends the accepted payload to a bounded in-memory session history, and sends that payload to each framework PlayerController using an owner-targeted Client RPC. This avoids a permanently replicated global transcript and keeps future moderation/channel/backend integrations at an authoritative server boundary.

A late joiner requests history once after local gameplay controller initialization. Client widgets maintain their own bounded display history. No chat data is written into `FDMFAccountRecord`, so chat cannot accidentally become account-save state.

## Manual ability command lifecycle

`UDMFDigimonCombatComponent` owns the authoritative quick-slot lifecycle. A client-owned request reaches the server through `UDMFPlayerDigimonComponent`, then resolves the equipped ability and validates target, leash and current SP. If the move cannot execute immediately because the Digimon is attacking/recovering, the ability is cooling down, the target is out of range, or target-facing is incomplete, the **latest valid command remains buffered on the server**. Automation revalidates the buffer until execution becomes legal or a bounded timeout/permanent invalidation clears it. SP and cooldown mutation happen only inside the successful authoritative execution path. Expired cooldown records are pruned instead of accumulating indefinitely.

## Replicated ability projectile architecture (v0.14.1)

`UDMFDigimonCombatComponent` now supports two execution models from the same authoritative ability Data Asset. **Timed Impact** preserves the original delayed-damage path. **Projectile** uses the same accepted cast validation/SP/cooldown/facing path but replaces the delayed damage callback with a delayed authoritative projectile launch.

`ADMFAbilityProjectileActor` is a replicated, Blueprintable cosmetic carrier whose movement is authored only by the server. The actor stores only the ability identity, source/target Digimon references and travel direction needed to reconstruct presentation. The server rotates/moves it toward the target (with optional bounded homing), detects arrival by segment-to-target distance, then calls back into the source combat component. Damage math and defeat/reward handling therefore stay in the same combat authority instead of moving into a client-visible projectile Blueprint.

Projectile visual orientation is decoupled from travel orientation through a child `VisualRoot`; designers can rotate/scale a fireball asset without changing the direction used for authoritative movement. Niagara is preferred, Cascade is fallback, and an optional Static Mesh may be carried by the same actor. Actor destruction on impact/invalid target/max lifetime guarantees cleanup of all attached projectile visuals. Optional impact VFX/audio are reconstructed from a lightweight multicast after authority accepts the arrival.

The legacy timed-impact presentation path now creates explicitly bounded transient VFX. Niagara/Cascade cues receive a forced cleanup timer even when the assigned effect loops forever. This prevents attack-socket particle accumulation without changing gameplay state or introducing replicated cosmetic components.

## Persistent identity

Species are immutable definitions (`UDMFDigimonSpeciesData`). Captured/materialized/starter Digimon are mutable instances (`FDMFDigimonInstance`) with a unique `FGuid`.

This separation is mandatory for:
- individual level/EXP/stat growth;
- attribute-point spending;
- current HP/SP;
- hunger/care state;
- learned/equipped abilities;
- Party/Bank storage location and active-partner identity;
- evolution history and later individuality systems.

## Account storage

`UDMFAccountPersistenceSubsystem` owns the host-side `UDMFAccountDatabaseSaveGame`. The first alpha uses one SaveGame database for ease of installation. A later database/backend provider can replace storage while retaining the `FDMFAccountRecord` contract.

## Frontend/network flow

1. Blank frontend map runs `ADMFFrontendGameMode`.
2. `ADMFFrontendHUD` creates the native `UDMFLoginMainMenuWidget`.
3. Login locally stages username + credential digest.
4. **Join Game** validates `Server Public Address / Hostname` + `Game Port` from Project Settings, then travels to that configured MMO endpoint with authentication options.
5. Server `PreLogin` validates credentials or auto-registers the account.
6. `InitNewPlayer` hydrates `ADMFPlayerState`, avatar state and Digimon state.
7. If the account requires a player skin, `UDMFPlayerSkinSelectionWidget` appears first and the server validates the selected `DMFPlayerSkin`.
8. Once avatar onboarding is complete, a new account requiring a Starter Digimon automatically sees `UDMFStarterSelectionWidget`.
9. Starter selection is sent as a Server RPC and validated against the configured starter roster.
10. Server creates/persists/spawns the partner; returning players skip completed onboarding stages.

Admin flow uses the same frontend but requires the additional admin unlock before `Host & Play` can start the open-world map with `listen`. v0.10.2 preflights the project-configured player-facing endpoint, and v0.10.3 also moves the Admin hosting password into Project Settings using a transient editor setter that persists only a one-way digest. Endpoint and Admin-host deployment configuration are therefore centralized without moving gameplay authority into UI.

## Expansion points already reserved

The account record now actively uses Digimon Bank storage alongside Party state and Scan progress, while money, ranked points and F→S+ tier remain reserved expansion fields. Keeping these systems in the same account schema lets later components extend the authoritative record instead of inventing parallel saves.

## Primary Asset discovery and packaged builds

`DMFDigimonSpeciesData`, `DMFStarterRosterData`, `DMFDigimonAbilityData` and `DMFPlayerSkinData` return explicit Primary Asset IDs. The consuming project should scan `/Game/DigimonData` for these types and cook them with `AlwaysCook`; a merge-ready `ConfigTemplates/DMF_Project_DefaultGame.ini.snippet` is included. The template intentionally appends entries and never clears the project's existing Asset Manager configuration.

Framework scalar defaults (port, capacities, spawn offset, save slot) live in C++ and can be overridden through **Project Settings → Game → Digimon MMO Framework**.


## Real-time combat layer

`ADMFDigimonCharacter` owns a static replicated `UDMFDigimonCombatComponent`. This component is the single battle runtime for owned partners, wild encounters, NPC teams and future ranked teams.

The server alone mutates HP/SP, cooldowns, targets and defeat state. Player ability requests enter through the owning `ADMFPlayerState -> UDMFPlayerDigimonComponent` connection and are revalidated against the current active partner, target hostility, ability slot, range, SP and cooldown.

Transient animation/VFX/audio are emitted as multicast cosmetic cues. Replicated combat properties remain the durable truth, so a dropped cosmetic packet cannot corrupt gameplay.

Autonomous target acquisition uses a bounded pawn overlap at a configurable interval instead of scanning every actor every frame. Partners use the player's pawn as their follow/leash anchor; wild/NPC Digimon use their spawn location as home.
## Rendering / cel-shading contract

Player-avatar and Digimon presentation bases enforce an always-on Custom Depth contract across their owned `UMeshComponent`s. This is intentionally presentation-local rather than replicated gameplay state. `ADMFPlayerAvatarCharacter` reapplies the contract after every data-driven skin swap; `ADMFDigimonCharacter` reapplies it at construction/BeginPlay and instance/state refresh boundaries. This keeps post-process cel shading deterministic across listen host, remote clients and packaged builds without storing redundant render flags in account saves or network state.



## Wild population / rarity spawning (v0.4.0)

`ADMFWildDigimonSpawner` is an authority-only decision maker wrapped in a replicated world actor. Clients never create wild populations or roll rarity/level. The server periodically counts real player pawns around the spawner, activates with a smaller radius, and unloads only after every required player has exceeded the larger deactivation radius for the configured grace period.

Activation chooses a target population within the designer min/max range. Initial actor creation is staggered. Each spawn selects from currently eligible entries using `rarity base weight * entry multiplier`; finite per-entry live caps are respected, and a fully capped table clamps the target population to the table's theoretical capacity.

Placement samples uniformly over the spawner disk, traces terrain, optionally projects onto NavMesh, rejects points too close to players, then uses collision-aware deferred spawning so Species/Level/rarity/AI/roam/emergence values exist before `BeginPlay`.

Spawner-managed `ADMFWildDigimonCharacter` actors replicate `SpawnRarity`, `SpawnHomeLocation` and ground-transition timing state. Idle roam requests are server-only and timer-driven. Combat automation's existing home/leash snapshot is the same individual spawn position, so roaming and combat share one bounded spatial contract.

Ground emergence is cosmetic-state replication rather than per-frame transform replication: the actor/capsule exists at the valid authoritative ground point while the inherited skeletal mesh interpolates from a negative relative-Z offset using synchronized server time. Combat, movement and collision are gated during the transition. The same mechanism supports optional ground-sink unload before actor destruction.

Defeat marks a managed actor dead immediately for population accounting, retains it for the configured death-presentation time, and creates one delayed replacement token. This separates corpse lifetime from respawn cadence and prevents instant pop-in replacement.


## Native player interaction / targeting (v0.5.2)

`ADMFPlayerAvatarCharacter` now owns the normal interaction entry surface. `Interact()` performs a local camera-forward Visibility trace/sphere sweep, ignores the player and optionally the player's active partner, then internally dispatches supported framework actors. This keeps the project-facing Blueprint contract at the pawn level instead of requiring every project to reconstruct the same controller/PlayerState casts.

A Digimon hit does not create new authority. The player wrapper resolves the local `ADMFMMOPlayerController` and forwards target-only or target+attack intent through the existing owner-routed `UDMFPlayerDigimonComponent` server RPCs. Local prevalidation checks that an active partner exists and that its combat component considers the Digimon hostile/targetable; server validation remains authoritative.

A healer hit is forwarded through the same client-owned PlayerController ingress already used by v0.5.0. `ADMFHealerActor` now owns a native query-only `USphereComponent` interaction volume sized from its separate `InteractionCollisionRadius`, which makes the default player trace usable without depending on cosmetic mesh collision.

The interaction layer exposes generic Actor-taking wrappers (`InteractWithActor`, `InteractWithDigimon`, `InteractWithHealer`, etc.) so Blueprint overlap/UI systems can remain cast-free. `BP_OnUnhandledInteraction` is intentionally non-authoritative extensibility for project-specific actor types.

## Manual owned-partner combat and role balance (v0.5.0)

Owned partners and wild Digimon now share the same combat runtime but no longer share the same automation policy. `UDMFPlayerDigimonComponent::SpawnOrRefreshActivePartner` configures owned partners from framework settings with autonomous battle disabled by default, while `ADMFWildDigimonCharacter` retains its own `bAutoBattle` behavior. The automation tick always maintains follow-anchor locomotion independently of auto battle, so disabling autonomous attacks does not turn the partner into a stationary actor.

Player commands still enter through the owner-routed PlayerState component. `CommandPartnerTargetAndAttack` is an atomic convenience call at the controller layer; the server still performs the existing target, slot, SP, cooldown, leash and impact validations.

Combat role tuning is stored only in the server combat component (`OutgoingDamageMultiplier` / `IncomingDamageMultiplier`). Owned partners receive the project-level values when spawned; Wild Blueprint classes configure their own neutral/default values. The persistent `FDMFDigimonStats` record is not rewritten to achieve battle pacing.

## Digimon roster / summon UI (v0.5.0)

`UDMFDigimonInventoryWidget` is an owner-only presentation surface over the existing Fast Array inventory. It never owns collection authority. Selecting/summoning/recalling calls server RPCs on `UDMFPlayerDigimonComponent`; the server validates that the GUID exists in that player's replicated inventory. Recall destroys only the world actor and deliberately retains `ActivePartnerInstanceId`.

The native fallback is usable immediately and can be replaced by a Blueprint child through framework settings. v0.12 adds authoritative Party/Bank move and atomic-swap transactions plus the persistent Party Quick Access HUD; future work may layer drag/drop gestures, sorting and filtering over the same transaction API.

## Healer authority (v0.5.0)

`ADMFHealerActor` is a replicated world interaction endpoint. Because a placed healer is not client-owned, clients do not send a Server RPC directly to it. `RequestHeal` routes through the owning `ADMFMMOPlayerController`; the server controller then asks the healer to validate distance, enable state, exclusive-busy state and reuse timing. The healer invokes `UDMFPlayerDigimonComponent::HealAllOwnedDigimon`, which updates the complete Party, optional all Bank/Box storage, the live partner combat component and account persistence.

In v0.12.2 the station also owns a compact durable treatment state (`bHealingInProgress`, active healing PlayerState, healed count). One station accepts only one player during `HealingSequenceDuration`. Rendering machines reconstruct a native pulsing green point light, Niagara-preferred/Cascade-fallback VFX and attached Sound Cue locally from that state, so the healer gains synchronized presentation without per-frame replicated cosmetic transforms. Dedicated servers do not render the treatment rig. The legacy heal multicast remains cosmetic/backward-compatible.

### v0.5.3 defeated presentation
`UDMFDigimonCombatComponent::CombatState` is the replicated durable authority for defeated presentation. `ADMFDigimonCharacter` owns local montage/final-pose holding, movement/collision presentation and revive cleanup. This separates authoritative HP/state from cosmetic animation while still reconstructing correctly for late relevancy.


## v0.5.5 defeated-pose and wild reactive-combat contracts

Defeat presentation is owned by `ADMFDigimonCharacter`: a valid species Death Montage plays, then the character locks skeletal evaluation at Montage blend-out so both partner and wild subclasses share the same persistent defeated pose contract. Lifecycle owners decide removal/revival separately.

`UDMFDigimonCombatComponent` deliberately separates proactive acquisition (`bAutoBattleEnabled`) from reactive defense (`bRetaliateWhenAttacked` / transient retaliation state). Damage reception can establish a retaliation target without enabling nearest-hostile scans. This allows ordinary wild Digimon to be neutral until attacked while still defending themselves server-authoritatively.

`ADMFWildDigimonCharacter` exposes the designer policy and the spawner resolves it before deferred spawn completion. The recommended default is proactive aggression off and retaliation on.

## v0.6.0 native UI presentation layer

The native UMG fallbacks are now treated as a presentation layer over existing replicated/server-authoritative state rather than debug controls. `DMFNativeUIStyle` is private to the runtime module and provides the common visual language used by frontend, roster, starter, player-skin and combat widgets.

Portrait/icon ownership remains data driven: species portraits live on `DMFDigimonSpeciesData`, player portraits on `DMFPlayerSkinData`, and ability icons on `DMFDigimonAbilityData`. No image reference is replicated as a new gameplay transaction; UI resolves the already-configured Primary Asset locally from replicated IDs.

`UDMFDigimonInventoryWidget` renders the owner-only active Digimon Fast Array as a slot grid and invokes the same `UDMFPlayerDigimonComponent` server RPCs for summon/recall. `UDMFStarterSelectionWidget` and `UDMFPlayerSkinSelectionWidget` retain their existing authoritative selection components. `UDMFCombatQuickBarWidget` remains a local presentation/control surface for server commands.

The frontend adds `UDMFSessionSubsystem::Logout()` only for local staged credential/admin state. It does not delete or mutate the server account database.


## v0.6.1 player spawn / possession recovery layer

`ADMFMMOGameMode` now owns an explicit invariant: every gameplay PlayerController must possess `ADMFPlayerAvatarCharacter` or a derived project Blueprint. `HandleStartingNewPlayer` preserves Unreal's standard restart flow, then validates that invariant. Wrong/missing pawns are replaced authoritatively, and remote clients receive a `ClientRestart` reassertion. The PlayerController adds only a bounded owner-side acknowledgement/retry request; it never spawns a pawn locally. Skin/starter server transactions call back into the same invariant rather than duplicating spawn logic.


## v0.6.2 combat-facing layer
`ADMFDigimonCharacter` owns the shared turn-in-place presentation contract. `UDMFDigimonCombatComponent` decides when a target is in attack range and asks the character to face it before consuming resources/starting an ability. The facing loop is a bounded server timer active only while needed. Character replicated movement distributes yaw; target-facing is not client-authoritative. Movement-driven orientation is cached/restored around the attack so partner following, wild roaming and path chasing remain independent.


## v0.6.4 combat reach contract
Ability range is evaluated by the authoritative combat component as horizontal capsule-edge distance rather than actor-center distance. The same helper is used for direct validation, queued manual commands, wild/auto attacks, and impact-time revalidation. AI chase acceptance is derived from the same capsule-aware reach so navigation cannot settle outside a short-range attack's legal distance.

## v0.7.0 Scan Data / Materialization authority

`UDMFPlayerDigimonComponent` owns the authoritative per-account `ReplicatedScanData` array (`COND_OwnerOnly`). `HandleAuthoritativeBattleVictory` is the single mutation boundary for scan rewards. Species tuning comes from `UDMFDigimonSpeciesData`; no client-supplied reward values are accepted. Materialization is a server RPC that resolves the species, re-checks progress and capacity, validates a partner WorldActorClass, builds a unique `FDMFDigimonInstance`, subtracts the requirement, marks Collection replication dirty and persists immediately.

The native `UDMFDigimonInventoryWidget` is the shared tabbed Digimon menu shell. Its current native pages are **Party**, **Bank / Boxes**, **Scan & Materialize**, **Digivolution** and **Care**; later modules should extend this shell instead of creating unrelated full-screen menus. `UDMFScanNotificationWidget` is presentation-only and receives owner-client reward events after the server has mutated state.


## v0.8.0 virtual-pet Care authority

`UDMFPlayerDigimonComponent` is the authoritative Care state machine. `FDMFDigimonInstance::Care` remains part of the same owner-only replicated Fast Array and server account record as combat vitals/stats. Hunger decay is integrated from server UTC timestamps, feeding requests contain no client-provided reward/timing values, and successful serving/waste transitions persist through the existing account subsystem.

`UDMFDigimonSpeciesData` owns static tuning/presentation references: starting Hunger, decay rate, Hunger per serving, Feeding Montage play count/rate, text-writable hand socket, DigiMeat mesh/relative transform (including scale), feeding voices, waste delay range, poo mesh/world scale/ground offset/lifetime and fart sounds. Project-wide fallback DigiMeat/Poo meshes and timing values live in `UDMFFrameworkSettings`.

`ADMFDigimonCarePropActor` is a lightweight replicated presentation actor. The server creates/attaches DigiMeat or places waste on a ground trace, while every peer resolves the same species/global mesh from replicated `SpeciesId` + `PropType`. The actor forcibly disables collision, overlap generation and navigation influence. Waste lifespan is server-owned. As of v0.8.1, every Care-prop mesh also locally forces `Render CustomDepth Pass = true` and a Blueprint-tunable stencil value, matching the framework cel-shading invariant without adding replicated state.

Feeding deliberately crosses UI and world presentation layers: the server accepts/locks the care sequence, sends an owner-client start event, and waits a configurable lead-in before the first Montage. `ADMFMMOPlayerController` removes the Digimon Menu/quickbar and restores game input so the 3D animation is visible. Completion recreates the shared menu directly on `CARE`. This owner-side presentation never mutates Hunger.

`ADMFDigimonCharacter` provides reliable multicast cosmetic cues for feeding Montage/voice and waste/fart presentation. The server chooses audio indices. Care locks existing combat/partner command RPCs for the duration so clients cannot race feeding against target/ability/recall state.


## v0.9.0 World Nameplate presentation layer

`ADMFPlayerAvatarCharacter` and `ADMFDigimonCharacter` each own a non-authoritative `UWidgetComponent` configured for crisp Screen-space presentation. At BeginPlay/replication refresh the actor resolves the global framework settings, applies enable/cull/height rules, initializes the selected native or Blueprint widget class, and gives the widget an observed actor.

`UDMFWorldNameplateWidget` is deliberately shared so the framework has one compact presentation contract while still exposing separate project-level Player/Digimon widget-class overrides. The native fallback collapses Digimon-only metadata/HP when observing a player, and expands the same small panel for Digimon identity/type/health. It polls presentation at a throttled interval rather than inventing replicated UI state.

Player username display uses `APlayerState::PlayerName`, which is the public display-name channel. Private account fields do not change their ownership contract. Digimon HP remains owned by `UDMFDigimonCombatComponent`; the plate is only a view of replicated combat truth.

## v0.14 DigiDex architecture

The native DigiDex is a **read-only local presentation layer** inside `UDMFDigimonInventoryWidget`. It enumerates `DMFDigimonSpecies` Primary Assets through `UAssetManager`, resolves the same `UDMFDigimonSpeciesData` records already used by combat/Scan/Digivolution, and derives discovery badges from the owning `UDMFPlayerDigimonComponent`'s existing Party, Bank and Scan state. No parallel species database, SaveGame field, server mutation path, or replicated DigiDex state exists.

`EDMFDigimonMenuTab::DigiDex` is appended after the v0.13 values so historical enum serialization remains stable. The native visual row may present tabs in a different order than their serialized enum values.

## v0.14.2 — local owner-only targeting presentation

### v0.14.3 visibility hardening
The local targeting presentation actor remains non-replicated and local-controller-owned, but its render components deliberately avoid Unreal `OnlyOwnerSee` filtering. Privacy comes from actor locality and owner-only gameplay state, not renderer ownership heuristics. This avoids camera/view-target ownership mismatches that can cull a local player's own markers. Missing soft assets are also refreshed lazily at runtime.

`ADMFTargetingPresentationActor` is a deliberately non-replicated local presentation actor spawned by the locally controlled `ADMFMMOPlayerController`. It reads the owning `UDMFPlayerDigimonComponent`'s already owner-only `ActivePartnerActor` and `CommandTarget` and reconstructs active-partner/selected-enemy visuals locally.

PaperSprite rings are moved from capsule dimensions rather than species-authored sockets, and optional capsule-radius scaling supports widely different Digimon sizes. A Niagara-preferred/Cascade-fallback target-arrow component follows the target capsule top. Marker rotation/bob are local cosmetic ticks only.

This layer never selects a target, does not call damage APIs, and introduces no marker replication. Server-authoritative target validation and ability execution remain in `UDMFPlayerDigimonComponent` / `UDMFDigimonCombatComponent`.
